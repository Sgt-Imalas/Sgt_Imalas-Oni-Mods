﻿using STRINGS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class STRINGS
    {
        public class BUILDINGS
        {
            public class PREFABS
            {
                
            }
        }
    }
}
