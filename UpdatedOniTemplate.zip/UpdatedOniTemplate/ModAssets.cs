﻿using Klei.AI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace $safeprojectname$
{
    internal class ModAssets
    {
       
    }
}
