﻿using HarmonyLib;
using KMod;
using System;

namespace $safeprojectname$
{
    public class Mod : UserMod2
    {
        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);
        }
    }
}
